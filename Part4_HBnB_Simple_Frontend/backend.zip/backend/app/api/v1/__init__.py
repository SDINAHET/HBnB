# #!/usr/bin/python3
# from flask_restx import Api
# from places import api as places_api

# api = Api()
# api.add_namespace(places_api)


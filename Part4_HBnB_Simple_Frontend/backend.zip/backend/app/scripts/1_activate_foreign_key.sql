-- Activer les clés étrangères
PRAGMA foreign_keys = ON;

--  sqlite3 development.db   begin sqlite3

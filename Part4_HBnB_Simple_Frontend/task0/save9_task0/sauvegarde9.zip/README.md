# Part4

## Login.html
email: admin@hbnb.com

password: admin1234
![alt text](images/image-4.png)

### success login
![alt text](images/image-7.png)

### invalid login
![alt text](images/image-8.png)

## index.html
![alt text](images/image-3.png)

### filtre max-price
![alt text](images/image-9.png)


## place.html
![alt text](images/image-5.png)
![alt text](images/image-6.png)


## add-review
![alt text](images/image-2.png)
![alt text](images/image.png)
![alt text](images/image-1.png)





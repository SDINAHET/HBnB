export const places = [
  {
    id: 1,
    name: "Beautiful Beach House",
    host: "John Doe",
    price: 150,
    description: "A beautiful beach house with amazing views...",
    amenities: "WiFi, Pool, Air Conditioning",
    reviews: [
      { author: "Jane Smith", comment: "Great place to stay!", rating: 4 },
      { author: "Robert Brown", comment: "Amazing location and very comfortable.", rating: 5 },
    ],
  },
  {
    id: 2,
    name: "Cozy Cabin",
    host: "Alice Johnson",
    price: 100,
    description: "A warm and inviting cabin in the woods.",
    amenities: "Fireplace, Hiking Trails, Mountain View",
    reviews: [
      { author: "Emma Wilson", comment: "So cozy and quiet!", rating: 5 },
    ],
  },
  {
    id: 3,
    name: "Modern Apartment",
    host: "Chris Lee",
    price: 200,
    description: "A sleek and stylish city apartment with modern amenities.",
    amenities: "Smart TV, High-Speed WiFi, Gym Access",
    reviews: [
      { author: "Liam Martinez", comment: "Perfect for business travel.", rating: 4 },
    ],
  },
  {
    id: 4,
    name: "Rustic Lakehouse",
    host: "Laura White",
    price: 180,
    description: "A charming lakehouse with a beautiful view of the sunset.",
    amenities: "Boat Dock, Fireplace, Private Garden",
    reviews: [
      { author: "Michael Scott", comment: "Absolutely stunning and relaxing!", rating: 5 },
      { author: "Pam Beesly", comment: "Perfect place for a getaway.", rating: 4 },
    ],
  },
  {
    id: 5,
    name: "Penthouse Suite",
    host: "David Beckham",
    price: 350,
    description: "A luxurious penthouse with panoramic city views.",
    amenities: "Private Pool, Rooftop Bar, 24/7 Butler Service",
    reviews: [
      { author: "Victoria Beckham", comment: "Luxury at its finest!", rating: 5 },
      { author: "Elton John", comment: "Absolutely worth it!", rating: 5 },
    ],
  },
];

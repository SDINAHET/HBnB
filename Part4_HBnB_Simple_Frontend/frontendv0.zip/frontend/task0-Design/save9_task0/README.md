# Part4
https://hbnb.alwaysdata.net/

## Login.html
email: admin@hbnb.com

password: admin1234
![alt text](image-4.png)

### success login
![alt text](image-7.png)

### invalid login
![alt text](image-8.png)

## index.html
![alt text](image-3.png)

### filtre max-price
![alt text](image-9.png)


## place.html
![alt text](image-5.png)
![alt text](image-6.png)


## add-review
![alt text](image-2.png)
![alt text](image.png)
![alt text](image-1.png)

![alt text](image-10.png)
